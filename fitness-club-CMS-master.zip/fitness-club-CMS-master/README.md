# fitness-club-CMS

the purpose is to create a content management system (cms) for the 'fitness club' so that the admin is able to send notifications, keep track of members, etc.
